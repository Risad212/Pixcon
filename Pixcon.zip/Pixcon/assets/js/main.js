/*[ Stiry navbar ]
===========================================================*/
var navbar = document.getElementById('navbar');

window.onscroll = function() {scrollFunction()};

// [Function]
//---------------------------
function scrollFunction() {
  if (document.body.scrollTop > 60 || document.documentElement.scrollTop > 60) {
    navbar.classList.add('menu-fixed')
  } else {
    navbar.classList.remove('menu-fixed')
  }
}


/*[ Back to top Button ]
===========================================================*/
var mybutton = document.getElementById("back-top");

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 90 || document.documentElement.scrollTop > 90) {
    mybutton.style.display = "block";
  } else {
    mybutton.style.display = "none";
  }
}

mybutton.addEventListener('click', function(){
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
})


/*[ Aos Call in here ]
===========================================================*/
AOS.init({
  offset: 250, // offset (in px) from the original trigger point
  delay: 500, // values from 0 to 3000, with step 50ms
  duration: 1000 // values from 0 to 3000, with step 50ms
});